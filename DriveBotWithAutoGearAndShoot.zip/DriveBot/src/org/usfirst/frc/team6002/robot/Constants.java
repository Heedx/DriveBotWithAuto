package org.usfirst.frc.team6002.robot;

public class Constants {
	//DRIVE
	public static final int kLeftFrontMotorId = 1;
	public static final int kLeftBackMotorId = 2;
	public static final int kRightFrontMotorId = 3;
	public static final int kRightBackMotorId = 4;
	
	//DRIVE SHIFT TARGETS
	//this is in relation to RPM of drive motors
	public static double kShiftTarget = 1000;
	
	//Drive PID values
	
	public static final double kMaxDrivePIDOutput = 0.5;
	public static final double kPDriving = 0.0005;
	public static final double kIDriving = 0.0;
	public static final double kDDriving = 0.002;
	
	//Turn PID Value
	public static final double kMaxTurnPIDOutput = 0.5;
	public static final double kPTurning = 0.05; //0.065
	public static final double kITurning = 0.0;
	public static final double kDTurning = 0.0;
	
	//Left front motor talon PID
	//Wheels turn at 670 in low
	//2400 in high
	//4573.867 native units per 100 ms
	public static final double kFLeftDriveVelocity = 0.2236619473;//0.265;
	public static final double kPLeftDriveVelocity = 1.7338983051;//0.14;
	public static final double kILeftDriveVelocity = 0.0;//0.0;
	public static final double kDLeftDriveVelocity = 0.0;//15;
	
	//Right front motor talon PID
	public static final double kFRightDriveVelocity = 0.2236619473;//0.254;
	public static final double kPRightDriveVelocity = 1.7338983051;//0.1;
	public static final double kIRightDriveVelocity = 0.0;//0.0;
	public static final double kDRightDriveVelocity = 0.0;//8;
	
	//COMPRESSOR
	public static int kCompressorId = 0;
	public static int kGearShiftLow = 0;
	public static int kGearShiftHigh = 1;
	
	//CLIMBER
	public static int kClimberId = 1;
	public static int kClimber2Id = 4;// second climber motor on comp robot
	
	//ROLLERS
	public static int kIntakeId = 2;
	public static int kConveyorId = 3;
	public static double kIntakeVoltage = 0.8;
	//Conveyor
	public static double kConveyorVoltage = 0.5;
	public static double kConveyorReverseVoltage = -0.5;
	
	//SHOOTER AND SERIALIZER
	public static int kMasterShooterId = 16;
	public static int kSlaveShooterId = 17;
	public static int kSerializerId = 0;
	
	public static double kSerializerVoltage = 0.75;
	
	public static double kShooterSpeed = 1200;
	public static double kShooterVoltage = 0.8;
	
	//SHOOTER PID values
	public static double kFShooterVelocity = 2.8416;
	public static double kPShooterVelocity = 12.115;
	public static double kIShooterVelocity = 0.0;
	public static double kDShooterVelocity = 0.0;
	
	//GEARARM
	public static int kGearArmId = 15;
	public static double kPGearArm = 1.2; //0.4
	public static double kIGearArm = 0.00035; //0.00035
	public static double kDGearArm = 0; //0
	
	//Gear arm positions
	public static double kGearArmHome = -0.035;
	public static double kGearArmDrop = 0.4;
	public static double kGearArmInbound = 0.1;

	//Robot's mechanics
	public static int kWheelDiameter = 4;//inches
	public static double kWheelCircumference = kWheelDiameter * Math.PI;
	//This variable is determined by applying full voltage to the motor 
	//and checking the speed with the web browser
	public static double kMaxDriveRPM = 1074;

	//Encoder
	public static double kTicksPerRotation = 1024; //The encoder on the drive train is 500 ticks per rotation
	//For the talons, their unit is (4 * encoder ticks per rotation(CPR))/rotation
	public static double kNativeUnitsPerRotation = 4 * kTicksPerRotation;
	//The robot travels (wheel's circumference / ticks per rotation) for every encoder tick(pulse)
	public static double kInchPerPulse = kWheelCircumference / kTicksPerRotation;
}
