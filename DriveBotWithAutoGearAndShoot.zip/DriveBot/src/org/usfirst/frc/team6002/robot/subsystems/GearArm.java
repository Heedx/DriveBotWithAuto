package org.usfirst.frc.team6002.robot.subsystems;

import edu.wpi.first.wpilibj.Counter;
import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.DoubleSolenoid;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

import org.usfirst.frc.team6002.robot.Robot;
import org.usfirst.frc.team6002.robot.Constants;
import com.ctre.CANTalon;
import com.ctre.CANTalon.TalonControlMode;

/**
 *
 */
public class GearArm extends Subsystem {

    // Put methods for controlling this subsystem
    // here. Call these from Commands.
	CANTalon gearArmMotor;
	DoubleSolenoid gearClaw;
	DigitalInput gearLimitSwitch;
	Counter gearSwitchCheck;
	private boolean wantsToDrop;
	private boolean hasGear;
	private boolean clawToggle;
	private boolean getGearToggle;
    public void initDefaultCommand() {
        // Set the default command for a subsystem here.
        //setDefaultCommand(new MySpecialCommand());
    	
    }
    private enum SystemState{
    	HOME,	//Arm in the up position
    	HELD, // Arm in home position with gear
    	LOWERED, //Arm lowered to the ground
    	RELEASED, //Gear is on peg
    	CAPTURED //Arm lowered to the ground with gear
    }
    private enum WantedState{
    	WANT_TO_CAPTURE_GEAR, //Wants to capture gear and raise arm
    	WANT_TO_PLACE_GEAR, //Wants to release gear on peg
    	WANT_TO_PREPARE_FOR_CAPTURE //Wants to get arm in position for capture
    }
    private SystemState mSystemState = SystemState.HELD;
    private WantedState mWantedState = WantedState.WANT_TO_PREPARE_FOR_CAPTURE;
    
    private boolean tightGearPickUp = false;
    public void update() {
    	if(getGetGearToggle()){
    		if(mSystemState == SystemState.HOME || mSystemState == SystemState.RELEASED){
    			lowerGear();
    			mSystemState = SystemState.LOWERED;
    		}
    		else if(mSystemState == SystemState.LOWERED || mSystemState == SystemState.CAPTURED){
    			homeGear();
    			if(mSystemState == SystemState.LOWERED){
    				mSystemState = SystemState.HOME;
    			}else{
    				mSystemState = SystemState.HELD;
    			}
    		}
    		setGetGearToggle(false);
    	}else if(wantsToDrop == true){	
//    		lowerGear();
    		DropGear();
    	}else if(gearLimitSwitch.get() == false && mSystemState == SystemState.LOWERED){
    		CaptureAndLift();
    	}
    }

    public void CaptureAndLift(){
    	closeClaw();
		if(tightGearPickUp){
//			backup
			tightGearPickUp = false; //Clear out indicator
			mSystemState = SystemState.CAPTURED;
			System.out.println("backup");
		}else{
			Timer.delay(0.1);
			homeGear();
			mSystemState = SystemState.HELD;
		}
    }
    public void DropGear(){
    	openClaw();
		wantsToDrop = false;
		mSystemState = SystemState.RELEASED;
    }
    public GearArm(){
       	getGearToggle = false;
       	hasGear = false;
       	clawToggle = false;
    	gearLimitSwitch = new DigitalInput(0);
    	gearSwitchCheck = new Counter(gearLimitSwitch);
    	gearClaw = new DoubleSolenoid(2,3);
    	gearArmMotor = new CANTalon(Constants.kGearArmId);
    	gearArmInit();
    }
    public void gearArmInit(){
    	gearArmMotor.enableBrakeMode(true);
    	gearArmMotor.setFeedbackDevice(CANTalon.FeedbackDevice.CtreMagEncoder_Relative);
        gearArmMotor.reverseSensor(false);
        gearArmMotor.reverseOutput(false);
        gearArmMotor.setProfile(0);
        gearArmMotor.setPID(Constants.kPGearArm, Constants.kIGearArm, Constants.kDGearArm);
    	gearArmMotor.changeControlMode(TalonControlMode.Position);
        gearArmMotor.setPosition(0.26);
    }
    
	public void setDesiredAngle(double gearArmTarget){
		//gearArmMotor.changeControlMode(CANTalon.TalonControlMode.Position);
		gearArmMotor.set(gearArmTarget);
	}
	public void zeroGearArmSensors(){
		gearArmMotor.setPosition(0.00);
//		System.out.println("gear arm position set to 0");
	}
	public void setGearArmInVBus(){
		gearArmMotor.changeControlMode(TalonControlMode.PercentVbus);
	}
	public void slowMove(){
		gearArmMotor.set(0.1);
	}
	public void homeGear(){
		setDesiredAngle(0.26);
	}
	public void lowerGear(){
		setDesiredAngle(0.00);
	}
	public void switchGetGearToggle(){
		getGearToggle = !getGearToggle;
	}
	public void setGetGearToggle(boolean val){
		getGearToggle = val;
	}
	public boolean getGetGearToggle(){
		return getGearToggle;
	}
	public void openClaw(){
		gearClaw.set(DoubleSolenoid.Value.kReverse);
	}
	public void closeClaw(){
		gearClaw.set(DoubleSolenoid.Value.kForward);
	}
	public boolean getClawToggle(){
		return clawToggle;
	}
	public void setClawToggle(boolean value){
		clawToggle = value;
	}
	public void switchClawToggle(){
		clawToggle = !clawToggle;
	}
	public void setTightPickUp(boolean val){
		tightGearPickUp = val;
	}
	public DigitalInput gearLimitSwitch(){
		return gearLimitSwitch;
	}
	public void resetSwitchCounter(){
		gearSwitchCheck.reset();
	}
	public boolean isGearIn(){
		return gearSwitchCheck.get() > 0;
	}
	public boolean wantsToDrop(){
		return wantsToDrop();
	}
	public void setWantsToDrop(boolean val){
		wantsToDrop = val;
	}
	public double getGearArmEncPosition(){
		return gearArmMotor.getPosition();
	}
	public void outputToSmartDashBoard(){
		SmartDashboard.putBoolean("Gear_LimitSwitch", gearLimitSwitch.get());
	}
	
	
	
	
}